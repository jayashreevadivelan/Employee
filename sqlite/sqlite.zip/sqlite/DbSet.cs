﻿namespace SQLiteAspNetCoreDemo
{
    public class DbSet
    {
    }
}